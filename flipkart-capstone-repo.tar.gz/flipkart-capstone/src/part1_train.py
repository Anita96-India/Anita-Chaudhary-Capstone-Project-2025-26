from pathlib import Path
import json, joblib
import numpy as np, pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, recall_score, precision_score, roc_auc_score
from sklearn.inspection import permutation_importance

ROOT=Path(__file__).resolve().parents[1]; MODELS=ROOT/'models'; REPORTS=ROOT/'reports'; MODELS.mkdir(exist_ok=True); REPORTS.mkdir(exist_ok=True)
df=pd.read_csv(ROOT/'orders_dataset.csv')
X=df.drop(columns=['returned','order_id']); y=df.returned
cat=['product_category','payment_method']; num=[c for c in X.columns if c not in cat]
pre=ColumnTransformer([('num',Pipeline([('imp',SimpleImputer(strategy='median')),('scale',StandardScaler())]),num),('cat',Pipeline([('imp',SimpleImputer(strategy='most_frequent')),('oh',OneHotEncoder(handle_unknown='ignore'))]),cat)])
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42,stratify=y)
def metrics(y,pred,prob=None):
 d={'accuracy':accuracy_score(y,pred),'f1':f1_score(y,pred,zero_division=0),'recall':recall_score(y,pred,zero_division=0),'precision':precision_score(y,pred,zero_division=0)}
 if prob is not None:d['roc_auc']=roc_auc_score(y,prob)
 return {k:round(float(v),4) for k,v in d.items()}
def sweep(y,prob):
 rows=[]
 for t in np.arange(.1,.901,.01):
  pr=(prob>=t).astype(int); rows.append({'threshold':round(float(t),2),**metrics(y,pr)})
 return rows,max(rows,key=lambda r:r['f1'])
# verification
verify={'rows':len(df),'columns':len(df.columns),'return_rate':df.returned.mean(),'rating_missing_pct':100*df.rating_given.isna().mean(),'missing_cod_pct':100*df.loc[df.payment_method.eq('COD'),'rating_given'].isna().mean(),'missing_non_cod_pct':100*df.loc[~df.payment_method.eq('COD'),'rating_given'].isna().mean(),'category_return_rate':df.groupby('product_category').returned.mean().to_dict(),'payment_return_rate':df.groupby('payment_method').returned.mean().to_dict()}
# dummy
dummy=Pipeline([('pre',pre),('model',DummyClassifier(strategy='most_frequent'))]).fit(Xtr,ytr); dpr=dummy.predict(Xte); dummy_m=metrics(yte,dpr)
# logistic
log=Pipeline([('pre',pre),('model',LogisticRegression(class_weight='balanced',max_iter=2000,random_state=42))]).fit(Xtr,ytr); lp=log.predict_proba(Xte)[:,1]; log_default=metrics(yte,(lp>=.5).astype(int),lp); log_rows,log_best=sweep(yte,lp)
# rf grid
rf=Pipeline([('pre',pre),('model',RandomForestClassifier(class_weight='balanced',random_state=42,n_jobs=-1))])
grid=GridSearchCV(rf,{'model__n_estimators':[100,200],'model__max_depth':[6,10,None]},scoring='roc_auc',cv=StratifiedKFold(5,shuffle=True,random_state=42),n_jobs=-1,return_train_score=False).fit(Xtr,ytr)
best=grid.best_estimator_; rp=best.predict_proba(Xte)[:,1]; rf_auc=roc_auc_score(yte,rp); rf_rows,rf_best=sweep(yte,rp); thr=rf_best['threshold']; rpred=(rp>=thr).astype(int)
joblib.dump(best,MODELS/'return_risk_model.pkl'); (MODELS/'return_risk_threshold.json').write_text(json.dumps({'t_star_rf':thr,'high_cutoff':min(1.0,round(thr+.15,2))},indent=2))
# importances transformed names
names=best.named_steps['pre'].get_feature_names_out(); imp=best.named_steps['model'].feature_importances_; top_idx=np.argsort(imp)[::-1][:5]
# permutation on ORIGINAL features using ROC-AUC, then compare top transformed feature's parent
perm=permutation_importance(best,Xte,yte,n_repeats=10,random_state=42,scoring='roc_auc',n_jobs=-1)
orig_perm=dict(zip(X.columns,perm.importances_mean))
def parent(n):
 s=n.split('__',1)[-1]
 for c in cat:
  if s.startswith(c+'_'): return c
 return s
importance=[{'feature':names[i],'impurity':float(imp[i]),'parent':parent(names[i]),'permutation_parent':float(orig_perm.get(parent(names[i]),0))} for i in top_idx]
# subgroup at chosen RF threshold
def subgroup(col):
 out={}
 for val in sorted(Xte[col].unique()):
  m=Xte[col].eq(val); out[str(val)]={'n':int(m.sum()),'recall':float(recall_score(yte[m],rpred[m],zero_division=0)),'precision':float(precision_score(yte[m],rpred[m],zero_division=0))}
 return out
report={'verification':verify,'dummy':dummy_m,'logistic_default':log_default,'logistic_best_threshold':log_best,'rf_best_params':grid.best_params_,'rf_cv_roc_auc':float(grid.best_score_),'rf_test_roc_auc':float(rf_auc),'rf_best_threshold':rf_best,'top5_importance':importance,'overall_rf_at_tstar':metrics(yte,rpred,rp),'subgroup_product_category':subgroup('product_category'),'subgroup_payment_method':subgroup('payment_method')}
(REPORTS/'part1_metrics.json').write_text(json.dumps(report,indent=2))
pd.DataFrame(log_rows).to_csv(REPORTS/'logistic_threshold_sweep.csv',index=False); pd.DataFrame(rf_rows).to_csv(REPORTS/'rf_threshold_sweep.csv',index=False)
print(json.dumps(report,indent=2))
