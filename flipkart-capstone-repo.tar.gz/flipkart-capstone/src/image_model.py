from pathlib import Path
import torch
from torch import nn
from PIL import Image
from torchvision import models, transforms
ROOT=Path(__file__).resolve().parents[1]
def load_product_classifier(path=ROOT/'models/product_classifier.pt'):
 ckpt=torch.load(path,map_location='cpu',weights_only=False); m=models.resnet18(weights=models.ResNet18_Weights.DEFAULT)
 if 'head_state_dict' in ckpt:
  head=nn.Linear(m.fc.in_features,10); head.load_state_dict(ckpt['head_state_dict']); m.fc=head
 else: m.fc=nn.Linear(m.fc.in_features,10); m.load_state_dict(ckpt['state_dict'])
 m.eval(); return m,ckpt
def predict_image(image_path):
 m,c=load_product_classifier(); tf=transforms.Compose([transforms.Grayscale(3),transforms.Resize((c['input_size'],c['input_size'])),transforms.ToTensor(),transforms.Normalize([.485,.456,.406],[.229,.224,.225])]); x=tf(Image.open(image_path)).unsqueeze(0)
 with torch.no_grad(): p=torch.softmax(m(x),1)[0]; conf,idx=p.max(0)
 return {'category':c['labels'][idx.item()],'confidence':float(conf)}
