from pathlib import Path
import json, joblib, pandas as pd
from image_model import predict_image
ROOT=Path(__file__).resolve().parents[1]
def check_return_risk(order_features:dict)->dict:
 model=joblib.load(ROOT/'models/return_risk_model.pkl'); cfg=json.loads((ROOT/'models/return_risk_threshold.json').read_text()); p=float(model.predict_proba(pd.DataFrame([order_features]))[0,1]); t=cfg['t_star_rf']; high=cfg['high_cutoff']; bucket='Low' if p<t else ('High' if p>=high else 'Medium'); return {'return_probability':round(p,4),'risk_bucket':bucket,'t_star_rf':t,'high_cutoff':high}
def classify_product_image(image_path:str)->dict: return predict_image(image_path)
