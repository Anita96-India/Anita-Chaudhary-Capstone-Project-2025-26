from pathlib import Path
import json, re, pickle, numpy as np
from sentence_transformers import SentenceTransformer
import faiss
ROOT=Path(__file__).resolve().parents[1]
docs=json.loads((ROOT/'policy_kb/policies.json').read_text()); chunks=[]
for d in docs:
 for i,s in enumerate([x.strip() for x in re.split(r'(?<=[.!?])\s+',d['text']) if x.strip()]): chunks.append({'chunk_id':f"{d['id']}_C{i+1}",'doc_id':d['id'],'text':s})
model=SentenceTransformer('all-MiniLM-L6-v2'); emb=model.encode([c['text'] for c in chunks],normalize_embeddings=True).astype('float32'); index=faiss.IndexFlatIP(emb.shape[1]); index.add(emb)
faiss.write_index(index,str(ROOT/'policy_kb/policy.faiss')); (ROOT/'policy_kb/chunks.json').write_text(json.dumps(chunks,indent=2))
print('documents',len(docs),'chunks',len(chunks))
