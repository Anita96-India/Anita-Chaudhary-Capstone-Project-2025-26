from pathlib import Path
import json,faiss
from sentence_transformers import SentenceTransformer
ROOT=Path(__file__).resolve().parents[1]; chunks=json.loads((ROOT/'policy_kb/chunks.json').read_text()); ans=json.loads((ROOT/'policy_kb/retrieval_answer_key.json').read_text()); idx=faiss.read_index(str(ROOT/'policy_kb/policy.faiss')); m=SentenceTransformer('all-MiniLM-L6-v2'); rows=[]
for x in ans:
 q=m.encode([x['query']],normalize_embeddings=True).astype('float32'); _,ii=idx.search(q,10); docs=[]
 for i in ii[0]:
  d=chunks[i]['doc_id']
  if d not in docs: docs.append(d)
  if len(docs)==3: break
 rel=set(x['relevant_docs']); got=set(docs); hit=len(rel&got); rows.append({'query':x['query'],'relevant':sorted(rel),'retrieved_at_3':docs,'hits':hit,'precision_at_3':hit/3,'recall_at_3':hit/len(rel)})
out={'per_query':rows,'average_precision_at_3':sum(r['precision_at_3'] for r in rows)/len(rows),'average_recall_at_3':sum(r['recall_at_3'] for r in rows)/len(rows)}; (ROOT/'reports/retrieval_eval.json').write_text(json.dumps(out,indent=2)); print(json.dumps(out,indent=2))
