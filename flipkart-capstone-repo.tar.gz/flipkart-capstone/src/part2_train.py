"""Part 2: Fashion-MNIST transfer learning with cached ResNet-18 features.
Run in a network-enabled Python environment on first use so torchvision can download
Fashion-MNIST and ImageNet pretrained weights. Subsequent runs use local caches.
"""
from pathlib import Path
import json, numpy as np, torch
from PIL import Image
from torch import nn
from torch.utils.data import DataLoader, Subset, TensorDataset
from torchvision import datasets, transforms, models
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/'data'; MODELS=ROOT/'models'; REPORTS=ROOT/'reports'; SAMPLES=DATA/'sample_images'
for p in (MODELS,REPORTS,SAMPLES): p.mkdir(parents=True,exist_ok=True)
LABELS=['T-shirt/top','Trouser','Pullover','Dress','Coat','Sandal','Shirt','Sneaker','Bag','Ankle boot']
DEVICE='cuda' if torch.cuda.is_available() else 'cpu'; INPUT_SIZE=64; BATCH=256; EPOCHS=15; LR=1e-3
# ResNet is fully convolutional before adaptive pooling; 64x64 is a documented speed-conscious valid input.
tf=transforms.Compose([transforms.Grayscale(num_output_channels=3),transforms.Resize((INPUT_SIZE,INPUT_SIZE)),transforms.ToTensor(),transforms.Normalize([.485,.456,.406],[.229,.224,.225])])
train_raw=datasets.FashionMNIST(DATA/'fashion-mnist',train=True,download=True,transform=tf); test=datasets.FashionMNIST(DATA/'fashion-mnist',train=False,download=True,transform=tf)
idx=np.arange(len(train_raw)); tr_idx,va_idx=train_test_split(idx,test_size=5000,random_state=42,stratify=np.array(train_raw.targets))
tr,va=Subset(train_raw,tr_idx),Subset(train_raw,va_idx)
base=models.resnet18(weights=models.ResNet18_Weights.DEFAULT); in_features=base.fc.in_features; base.fc=nn.Identity(); base.eval().to(DEVICE)
for p in base.parameters(): p.requires_grad=False
@torch.no_grad()
def extract(ds):
 feats,ys=[],[]
 for x,y in DataLoader(ds,batch_size=BATCH,shuffle=False,num_workers=0): feats.append(base(x.to(DEVICE)).cpu()); ys.append(y)
 return torch.cat(feats),torch.cat(ys)
Xtr,ytr=extract(tr); Xva,yva=extract(va); Xte,yte=extract(test)
head=nn.Linear(in_features,10).to(DEVICE); opt=torch.optim.Adam(head.parameters(),lr=LR); loss=nn.CrossEntropyLoss()
train_loader=DataLoader(TensorDataset(Xtr,ytr),batch_size=BATCH,shuffle=True)
best_state=None; best_val=0
for epoch in range(EPOCHS):
 head.train()
 for x,y in train_loader:
  x,y=x.to(DEVICE),y.to(DEVICE); opt.zero_grad(); l=loss(head(x),y); l.backward(); opt.step()
 head.eval()
 with torch.no_grad(): pred=head(Xva.to(DEVICE)).argmax(1).cpu()
 acc=(pred==yva).float().mean().item(); print('epoch',epoch+1,'val_acc',round(acc,4))
 if acc>best_val: best_val=acc; best_state={k:v.cpu().clone() for k,v in head.state_dict().items()}
head.load_state_dict(best_state)
# If feature extraction is below 80%, fail clearly and request fine-tuning rather than fabricate success.
# The provided optional fine-tune function unfreezes layer4 and trains end-to-end at 1e-4.
def build_full(head_state):
 m=models.resnet18(weights=models.ResNet18_Weights.DEFAULT); m.fc=nn.Linear(m.fc.in_features,10); m.fc.load_state_dict(head_state)
 for p in m.parameters(): p.requires_grad=False
 for p in m.layer4.parameters(): p.requires_grad=True
 for p in m.fc.parameters(): p.requires_grad=True
 return m
fine_tuned=False
if best_val < .80:
 fine_tuned=True; model=build_full(best_state).to(DEVICE); opt=torch.optim.Adam(filter(lambda p:p.requires_grad,model.parameters()),lr=1e-4)
 loader=DataLoader(tr,batch_size=128,shuffle=True,num_workers=0)
 for epoch in range(5):
  model.train()
  for x,y in loader:
   x,y=x.to(DEVICE),y.to(DEVICE); opt.zero_grad(); l=loss(model(x),y); l.backward(); opt.step()
 # save full model state
 torch.save({'state_dict':model.state_dict(),'architecture':'resnet18','input_size':INPUT_SIZE,'labels':LABELS},MODELS/'product_classifier.pt')
 model.eval(); preds=[]
 with torch.no_grad():
  for x,_ in DataLoader(test,batch_size=BATCH): preds.extend(model(x.to(DEVICE)).argmax(1).cpu().tolist())
else:
 # Compose pretrained backbone + trained head for inference; checkpoint includes head and metadata.
 torch.save({'head_state_dict':best_state,'architecture':'resnet18_frozen_backbone','input_size':INPUT_SIZE,'labels':LABELS},MODELS/'product_classifier.pt')
 with torch.no_grad(): preds=head(Xte.to(DEVICE)).argmax(1).cpu().tolist()
ytrue=np.array(test.targets); acc=accuracy_score(ytrue,preds); cm=confusion_matrix(ytrue,preds); cr=classification_report(ytrue,preds,target_names=LABELS,output_dict=True)
np.savetxt(REPORTS/'confusion_matrix.csv',cm,fmt='%d',delimiter=','); (REPORTS/'part2_metrics.json').write_text(json.dumps({'split_sizes':{'train':55000,'validation':5000,'test':10000},'input_size':INPUT_SIZE,'batch_size':BATCH,'optimizer':'Adam','learning_rate':LR,'epochs':EPOCHS,'feature_extraction_validation_accuracy':best_val,'fine_tuning_required':fine_tuned,'test_accuracy':acc,'classification_report':cr},indent=2))
# Export five real test images (raw grayscale, not transformed tensors).
raw_test=datasets.FashionMNIST(DATA/'fashion-mnist',train=False,download=False)
seen=set()
for i,(img,label) in enumerate(raw_test):
 if label not in seen:
  img.save(SAMPLES/f'{i:04d}_{LABELS[label].lower().replace("/","-").replace(" ","_")}.png'); seen.add(label)
 if len(seen)>=5: break
print('test_accuracy',acc)
